304903768
200978641
*****
Q7:
we built an MST with a branching factor limited to 2, in order to produce a minimal path through the dots,
 in addition weve factored in whether there's a wall in the subgrid between a pair of dots(because this adds at least 2 steps to the manhattan dist)
 